#!/usr/bin/env python3
"""
#TODO: I am trying to learn a good way to use sockets.
#? This implementation is a POC for other rewrites to avoid multiple IO and System calls.
Cava Manager and Client using Unix Sockets
This script can act as both a manager (server) and client (reader)
- Manager: Runs a single cava instance and broadcasts to multiple clients via socket
- Client: Connects to the socket and reads cava data with formatting
"""

import socket
import subprocess
import os
import sys
import threading
import time
import argparse
import signal
import atexit
import json
import shlex
import re
import fcntl
import tempfile
from pathlib import Path


class CavaConfig:
    """Handle Cava configuration loading and parsing from ~/.config/cava/config"""

    def __init__(self):
        self.config = self._load_config()

    def _load_config(self):
        """Load Cava configuration from ~/.config/cava/config"""
        config_dir = os.path.expanduser(os.getenv("XDG_CONFIG_HOME", "~/.config"))
        config_file = os.path.join(config_dir, "cava", "config")

        if not os.path.exists(config_file):
            return {}

        config = {}
        current_section = None
        
        try:
            with open(config_file, "r") as f:
                for line in f:
                    line = line.strip()
                    
                    # Skip empty lines and comments
                    if not line or line.startswith('#') or line.startswith(';'):
                        continue
                    
                    # Check for section headers [section_name]
                    if line.startswith('[') and line.endswith(']'):
                        current_section = line[1:-1].strip()
                        continue
                    
                    # Parse key = value pairs
                    if '=' in line and current_section:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip()
                        
                        # Store with section prefix (e.g., "general_bars", "input_method")
                        config_key = f"{current_section}_{key}"
                        config[config_key] = value
                        
        except Exception as e:
            print(f"Warning: Could not load Cava config: {e}", file=sys.stderr)

        return config

    def get_value(self, key, default=None):
        """Get value from Cava config, falling back to environment, then default
        
        For cava config compatibility, this method maps common cava settings:
        - CAVA_BARS -> general_bars
        - CAVA_RANGE -> output_ascii_max_range  
        - CAVA_CHANNELS -> output_channels
        - CAVA_REVERSE -> output_reverse
        """
        # Map common environment variables to cava config keys
        key_mapping = {
            'CAVA_BARS': 'general_bars',
            'CAVA_RANGE': 'output_ascii_max_range',
            'CAVA_CHANNELS': 'output_channels', 
            'CAVA_REVERSE': 'output_reverse',
            # Add more mappings as needed for specific prefixed versions
            'CAVA_WAYBAR_BARS': 'general_bars',
            'CAVA_WAYBAR_RANGE': 'output_ascii_max_range',
            'CAVA_WAYBAR_CHANNELS': 'output_channels',
            'CAVA_WAYBAR_REVERSE': 'output_reverse',
            'CAVA_STDOUT_BARS': 'general_bars',
            'CAVA_STDOUT_RANGE': 'output_ascii_max_range',
            'CAVA_STDOUT_CHANNELS': 'output_channels',
            'CAVA_STDOUT_REVERSE': 'output_reverse',
            'CAVA_HYPRLOCK_BARS': 'general_bars',
            'CAVA_HYPRLOCK_RANGE': 'output_ascii_max_range',
            'CAVA_HYPRLOCK_CHANNELS': 'output_channels',
            'CAVA_HYPRLOCK_REVERSE': 'output_reverse',
        }
        
        # Check if we have a mapping for this key
        cava_key = key_mapping.get(key)
        if cava_key and cava_key in self.config:
            value = self.config[cava_key]
            
            # Convert numeric strings to appropriate types
            if value.isdigit():
                return int(value)
            elif value.lower() in ('true', 'yes', 'on'):
                return 1
            elif value.lower() in ('false', 'no', 'off'):
                return 0
            else:
                return value
        
        # Fall back to environment variable
        env_value = os.getenv(key)
        if env_value is not None:
            # Try to convert to int if it's numeric
            if env_value.isdigit():
                return int(env_value)
            elif env_value.lower() in ('true', 'yes', 'on'):
                return 1
            elif env_value.lower() in ('false', 'no', 'off'):
                return 0
            else:
                return env_value
        
        # Return default
        return default

    def get_cava_value(self, section, key, default=None):
        """Get a value directly from a specific cava config section"""
        config_key = f"{section}_{key}"
        value = self.config.get(config_key)
        
        if value is not None:
            # Convert numeric strings and booleans
            if value.isdigit():
                return int(value)
            elif value.lower() in ('true', 'yes', 'on'):
                return True
            elif value.lower() in ('false', 'no', 'off'):
                return False
            else:
                return value
                
        return default


class MediaDetector:
    """Detect if media is playing using playerctl, PipeWire, or PulseAudio"""
    
    def __init__(self):
        self.last_check = 0
        self.check_interval = 0.5  # Check more frequently (every 0.5 seconds)
        self.cached_status = False
        self.playerctl_available = self._check_playerctl_available()
        self.audio_system = self._detect_audio_system()
    
    def _check_playerctl_available(self):
        """Check if playerctl is available"""
        try:
            subprocess.run(['playerctl', '--version'], 
                         stdout=subprocess.DEVNULL, 
                         stderr=subprocess.DEVNULL,
                         check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def _detect_audio_system(self):
        """Detect whether system uses PipeWire or PulseAudio"""
        try:
            result = subprocess.run(['pactl', 'info'], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=1)
            if 'PipeWire' in result.stdout:
                return 'pipewire'
            return 'pulseaudio'
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            return 'unknown'
    
    def _check_media_playerctl(self):
        """Check if media is playing using playerctl - most reliable method"""
        try:
            # Check all players
            result = subprocess.run(['playerctl', '-a', 'status'], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=1)
            # If any player is playing, return True
            statuses = result.stdout.strip().lower().split('\n')
            return 'playing' in statuses
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            return False
    
    def _check_audio_activity_pipewire(self):
        """Check if audio is active using PipeWire (pw-cli or wpctl)"""
        try:
            # Try wpctl first (more modern)
            result = subprocess.run(['wpctl', 'status'], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=1)
            # Look for active sinks/sources with RUNNING state
            lines = result.stdout.split('\n')
            for line in lines:
                if 'RUNNING' in line:
                    return True
            return False
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            try:
                # Fallback to pw-cli
                result = subprocess.run(['pw-cli', 'list-objects'], 
                                      capture_output=True, 
                                      text=True, 
                                      timeout=1)
                # Check for active streams
                return 'state = "running"' in result.stdout.lower()
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
                return False
    
    def _check_audio_activity_pulseaudio(self):
        """Check if any audio streams are active using pactl"""
        try:
            result = subprocess.run(['pactl', 'list', 'sink-inputs'], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=1)
            # Check for active sink inputs with RUNNING state
            if 'Sink Input #' not in result.stdout:
                return False
            # Look for corked (paused) state - if all are corked, nothing is playing
            lines = result.stdout.split('\n')
            has_running = False
            for i, line in enumerate(lines):
                if 'State:' in line:
                    if 'RUNNING' in line:
                        has_running = True
                    elif 'CORKED' in line:
                        continue
            return has_running
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            return False
    
    def is_media_playing(self, force_check=False):
        """Check if media is currently playing with caching"""
        current_time = time.time()
        
        # Use cached result if recent enough and not forcing
        if not force_check and current_time - self.last_check < self.check_interval:
            return self.cached_status
        
        # Try playerctl first if available (most reliable)
        if self.playerctl_available:
            self.cached_status = self._check_media_playerctl()
        else:
            # Fallback to audio system detection
            if self.audio_system == 'pipewire':
                self.cached_status = self._check_audio_activity_pipewire()
            else:
                self.cached_status = self._check_audio_activity_pulseaudio()
        
        self.last_check = current_time
        return self.cached_status


class CSSColorUpdater:
    """Update Waybar CSS colors dynamically for cava modules with atomic writes and file locking"""
    
    def __init__(self, css_file_path=None):
        if css_file_path is None:
            config_home = os.path.expanduser(os.getenv("XDG_CONFIG_HOME", "~/.config"))
            self.css_file_path = os.path.join(config_home, "waybar", "style.css")
        else:
            self.css_file_path = os.path.expanduser(css_file_path)
        
        self.backup_path = self.css_file_path + ".cava_backup"
        self.lock_path = self.css_file_path + ".lock"
        self.current_state = None  # Track current state to avoid redundant updates
        self.last_update = 0
        self.update_interval = 0.3  # Minimum time between updates
        
        # Create initial backup if it doesn't exist
        if os.path.exists(self.css_file_path) and not os.path.exists(self.backup_path):
            self._create_backup()
    
    def _create_backup(self):
        """Create a backup of the original CSS file"""
        try:
            with open(self.css_file_path, 'r') as src:
                content = src.read()
            with open(self.backup_path, 'w') as dst:
                dst.write(content)
            print(f"Created CSS backup: {self.backup_path}", file=sys.stderr)
        except Exception as e:
            print(f"Warning: Could not create backup: {e}", file=sys.stderr)
    
    def _acquire_lock(self, lock_file, timeout=5):
        """Acquire an exclusive lock on the file with timeout"""
        start_time = time.time()
        while True:
            try:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True
            except IOError:
                if time.time() - start_time > timeout:
                    print("Warning: Could not acquire lock on CSS file", file=sys.stderr)
                    return False
                time.sleep(0.01)  # Wait 10ms before retry
    
    def _release_lock(self, lock_file):
        """Release the lock on the file"""
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
        except Exception:
            pass
    
    def _update_css_color(self, make_transparent):
        """Update the CSS file to set cava colors to transparent or restore them using atomic write"""
        if not os.path.exists(self.css_file_path):
            print(f"Warning: CSS file not found: {self.css_file_path}", file=sys.stderr)
            return False
        
        lock_file = None
        temp_fd = None
        temp_path = None
        
        try:
            # Create/open lock file
            lock_file = open(self.lock_path, 'w')
            
            # Acquire exclusive lock with timeout
            if not self._acquire_lock(lock_file, timeout=5):
                return False
            
            # Read the current CSS file
            with open(self.css_file_path, 'r') as f:
                content = f.read()
            
            # Store original content for comparison
            original_content = content
            
            # Define the patterns for cava-left and cava-right blocks
            if make_transparent:
                # Change @primary to transparent in cava blocks
                pattern_left = r'(#custom-cava-left\s*\{[^}]*?color:\s*)@primary(\s*;)'
                content = re.sub(pattern_left, r'\1transparent\2', content)
                
                pattern_right = r'(#custom-cava-right\s*\{[^}]*?color:\s*)@primary(\s*;)'
                content = re.sub(pattern_right, r'\1transparent\2', content)
            else:
                # Restore transparent back to @primary in cava blocks
                pattern_left = r'(#custom-cava-left\s*\{[^}]*?color:\s*)transparent(\s*;)'
                content = re.sub(pattern_left, r'\1@primary\2', content)
                
                pattern_right = r'(#custom-cava-right\s*\{[^}]*?color:\s*)transparent(\s*;)'
                content = re.sub(pattern_right, r'\1@primary\2', content)
            
            # Check if any changes were actually made
            if content == original_content:
                # No changes needed, release lock and return
                self._release_lock(lock_file)
                lock_file.close()
                return True
            
            # Atomic write: write to temporary file first
            temp_fd, temp_path = tempfile.mkstemp(
                dir=os.path.dirname(self.css_file_path),
                prefix='.style_tmp_',
                suffix='.css'
            )
            
            # Write content to temp file
            with os.fdopen(temp_fd, 'w') as temp_file:
                temp_file.write(content)
                temp_file.flush()
                os.fsync(temp_file.fileno())  # Force write to disk
            
            # Get original file permissions
            original_stat = os.stat(self.css_file_path)
            os.chmod(temp_path, original_stat.st_mode)
            
            # Atomic rename (this is the critical atomic operation)
            os.rename(temp_path, self.css_file_path)
            temp_path = None  # Mark as successfully moved
            
            # Release lock
            self._release_lock(lock_file)
            lock_file.close()
            
            return True
            
        except Exception as e:
            print(f"Error updating CSS: {e}", file=sys.stderr)
            
            # Clean up temp file if it exists
            if temp_path and os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except Exception:
                    pass
            
            return False
        
        finally:
            # Ensure lock is released
            if lock_file:
                try:
                    self._release_lock(lock_file)
                    lock_file.close()
                except Exception:
                    pass
    
    def restore_from_backup(self):
        """Restore CSS from backup if it exists"""
        if os.path.exists(self.backup_path):
            try:
                with open(self.backup_path, 'r') as src:
                    content = src.read()
                with open(self.css_file_path, 'w') as dst:
                    dst.write(content)
                print("CSS restored from backup", file=sys.stderr)
                return True
            except Exception as e:
                print(f"Error restoring backup: {e}", file=sys.stderr)
                return False
        return False
    
    def update_for_media_state(self, is_playing):
        """Update CSS based on media playing state"""
        current_time = time.time()
        
        # Avoid redundant updates
        if self.current_state == is_playing and current_time - self.last_update < self.update_interval:
            return
        
        make_transparent = not is_playing
        if self._update_css_color(make_transparent):
            self.current_state = is_playing
            self.last_update = current_time
    
    def cleanup(self):
        """Cleanup: restore original colors when script exits"""
        try:
            # Restore to @primary_container on exit
            self._update_css_color(make_transparent=False)
            print("CSS colors restored on cleanup", file=sys.stderr)
        except Exception as e:
            print(f"Error during cleanup: {e}", file=sys.stderr)



class CavaDataParser:
    """Handle cava data parsing and formatting"""

    @staticmethod
    def format_data(line, bar_chars="▁▂▃▄▅▆▇█", width=None, standby_mode="", padding="", reverse=False):
        """Format cava data with custom bar characters (list or string) and optional padding"""
        line = line.strip()
        if not line:
            return CavaDataParser._handle_standby_mode(standby_mode, bar_chars, width)

        try:
            values = [int(x) for x in line.split(";") if x.isdigit()]
        except ValueError:
            return CavaDataParser._handle_standby_mode(standby_mode, bar_chars, width)

        if not values or all(v == 0 for v in values):
            return CavaDataParser._handle_standby_mode(standby_mode, bar_chars, width)

        if not width:
            width = len(values)

        if len(values) != width:
            expanded_values = []
            for i in range(width):
                original_pos = (i * (len(values) - 1)) / (width - 1) if width > 1 else 0

                left_idx = int(original_pos)
                right_idx = min(left_idx + 1, len(values) - 1)

                if left_idx == right_idx:
                    expanded_values.append(values[left_idx])
                else:
                    fraction = original_pos - left_idx
                    interpolated = (
                        values[left_idx]
                        + (values[right_idx] - values[left_idx]) * fraction
                    )
                    expanded_values.append(int(round(interpolated)))

            values = expanded_values

        # Reverse the values if requested (for right-side visualization)
        if reverse:
            values = list(reversed(values))

        bar_length = len(bar_chars)
        result_parts = []  # Changed from result = "" to list for easier joining

        for i, value in enumerate(values):
            if value >= bar_length:
                char_index = bar_length - 1
            else:
                char_index = value
            # bar_chars can be a list or string
            bar_char = bar_chars[char_index]
            result_parts.append(bar_char)
            
            # Add padding between bars (but not after the last bar)
            if i < len(values) - 1 and padding:
                result_parts.append(padding)

        return "".join(result_parts)

    @staticmethod
    def _handle_standby_mode(standby_mode, bar_chars, width):
        """Handle standby mode when no audio activity - matches bash script logic"""
        if isinstance(standby_mode, str):
            return standby_mode
        elif standby_mode == 0:
            return ""
        elif standby_mode == 1:
            return "‎ "
        elif standby_mode == 2:
            full_char = bar_chars[-1]
            return full_char * (width or len(bar_chars))
        elif standby_mode == 3:
            low_char = bar_chars[0]
            return low_char * (width or len(bar_chars))
        else:
            return str(standby_mode)


class CavaServer:
    """Cava server that manages the cava process and broadcasts to clients"""

    def __init__(self):
        self.runtime_dir = os.getenv(
            "XDG_RUNTIME_DIR", os.path.join("/run/user", str(os.getuid()))
        )
        self.socket_file = os.path.join(self.runtime_dir, "hyprcandy", "cava.sock")
        self.pid_file = os.path.join(self.runtime_dir, "hyprcandy", "cava.pid")
        self.temp_dir = Path(os.path.join(self.runtime_dir, "hyprcandy"))
        self.config_file = self.temp_dir / "cava.manager.conf"

        self.clients = []
        self.clients_lock = threading.Lock()
        self.cava_process = None
        self.server_socket = None
        self.cleanup_registered = False
        self.successfully_started = False
        self.consecutive_zero_count = 0
        self.zero_threshold = 50
        self.last_client_time = time.time()
        self.should_shutdown = False

    def _signal_handler(self, signum, frame):
        """Handle signals gracefully"""
        self.cleanup()
        sys.exit(0)

    def cleanup(self):
        """Cleanup function called on exit"""
        if not (
            self.successfully_started and (self.server_socket or self.cava_process)
        ):
            return

        print(f"Shutting down cava manager (PID: {os.getpid()})...")

        if self.cava_process and self.cava_process.poll() is None:
            self.cava_process.terminate()
            try:
                self.cava_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.cava_process.kill()

        with self.clients_lock:
            for client_socket in self.clients[:]:
                try:
                    client_socket.close()
                except Exception:
                    pass
            self.clients.clear()

        if self.server_socket:
            self.server_socket.close()

        if self.server_socket and os.path.exists(self.socket_file):
            owns_pid_file = False
            if os.path.exists(self.pid_file):
                try:
                    with open(self.pid_file, "r") as f:
                        pid = int(f.read().strip())
                    owns_pid_file = pid == os.getpid()
                except (ValueError, IOError, FileNotFoundError):
                    pass

            if owns_pid_file or not os.path.exists(self.pid_file):
                os.remove(self.socket_file)
                print(f"Removed socket file: {self.socket_file}")

        if self.server_socket and os.path.exists(self.pid_file):
            try:
                with open(self.pid_file, "r") as f:
                    pid = int(f.read().strip())
                if pid == os.getpid():
                    os.remove(self.pid_file)
                    print(f"Removed PID file: {self.pid_file}")
            except (ValueError, IOError, FileNotFoundError):
                pass

        print("Cleanup complete.")

    def _write_pid_file(self):
        """Write PID file to prevent multiple managers"""
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        with open(self.pid_file, "w") as f:
            f.write(str(os.getpid()))

    def _quick_check_running(self):
        """Quick check if manager is running without acquiring locks"""
        if os.path.exists(self.socket_file):
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as test_socket:
                    test_socket.settimeout(0.5)
                    test_socket.connect(self.socket_file)
                return True
            except (ConnectionRefusedError, FileNotFoundError, OSError, socket.timeout):
                try:
                    os.remove(self.socket_file)
                except FileNotFoundError:
                    pass

        if os.path.exists(self.pid_file):
            try:
                with open(self.pid_file, "r") as f:
                    pid = int(f.read().strip())

                try:
                    os.kill(pid, 0)
                    return True
                except OSError:
                    try:
                        os.remove(self.pid_file)
                    except FileNotFoundError:
                        pass
            except (ValueError, IOError):
                try:
                    os.remove(self.pid_file)
                except FileNotFoundError:
                    pass

        return False

    def _broadcast_data(self, data):
        """Broadcast data to all connected clients"""
        with self.clients_lock:
            disconnected_clients = []
            for client_socket in self.clients:
                try:
                    client_socket.sendall(data)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    disconnected_clients.append(client_socket)

            for client in disconnected_clients:
                try:
                    client.close()
                except Exception:
                    pass
                if client in self.clients:
                    self.clients.remove(client)

            # If no clients remain, just log it — manager stays alive to accept new connections
            if not self.clients:
                print("All clients disconnected, waiting for new connections...")

    def _handle_client_connections(self):
        """Handle incoming client connections and listen for reload command"""
        while not self.should_shutdown:
            try:
                conn, addr = self.server_socket.accept()
                print("New client connected")
                threading.Thread(
                    target=self._client_command_listener, args=(conn,), daemon=True
                ).start()
                with self.clients_lock:
                    self.clients.append(conn)
                    self.last_client_time = time.time()
            except OSError:
                break

    def _client_command_listener(self, conn):
        """Listen for special commands from a client (e.g., reload)"""
        try:
            conn.settimeout(0.1)
            data = b""
            while True:
                try:
                    chunk = conn.recv(1024)
                    if not chunk:
                        break
                    data += chunk
                    if b"\n" in data:
                        line, data = data.split(b"\n", 1)
                        if line.strip() == b"CMD:RELOAD":
                            print("Received reload command from client.")
                            self._reload_cava_process()
                except socket.timeout:
                    break
        except Exception:
            pass

    def _reload_cava_process(self):
        """Restart cava process and reload config with latest values"""
        print("Reloading cava process...")
        if self.cava_process and self.cava_process.poll() is None:
            self.cava_process.terminate()
            try:
                self.cava_process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.cava_process.kill()
        # Always use latest config values
        cava_config = CavaConfig()
        bars = int(cava_config.get_value("CAVA_BARS", 64))
        range_val = int(cava_config.get_value("CAVA_RANGE", 15))
        channels = cava_config.get_value("CAVA_CHANNELS", "stereo")
        reverse = cava_config.get_value("CAVA_REVERSE", 0)
        try:
            reverse = int(reverse)
        except Exception:
            reverse = 1 if str(reverse).lower() in ("true", "yes", "on") else 0
        self._create_cava_config(bars, range_val, channels, reverse)
        try:
            self.cava_process = subprocess.Popen(
                ["cava", "-p", str(self.config_file)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            print("Cava process restarted.")
        except FileNotFoundError:
            print("Error: cava not found. Please install cava.")

    def _create_cava_config(
        self, bars=16, range_val=15, channels="stereo", reverse=0, prefix=""
    ):
        """Create cava configuration file with channels and reverse support, using CavaConfig with or without prefix as appropriate"""
        cava_config = CavaConfig()

        if prefix:
            config_channels = cava_config.get_value(f"CAVA_{prefix}_CHANNELS")
            config_reverse = cava_config.get_value(f"CAVA_{prefix}_REVERSE")
        else:
            config_channels = cava_config.get_value("CAVA_CHANNELS")
            config_reverse = cava_config.get_value("CAVA_REVERSE")
        if config_channels in ("mono", "stereo"):
            channels = config_channels
        if config_reverse is not None:
            try:
                reverse = int(config_reverse)
            except ValueError:
                reverse = (
                    1 if str(config_reverse).lower() in ("true", "yes", "on") else 0
                )

        self.temp_dir.mkdir(parents=True, exist_ok=True)

        config_content = f"""[general]
bars = {bars}
sleep_timer = 1

[input]
method = pulse
source = auto

[output]
method = raw
raw_target = /dev/stdout
data_format = ascii
ascii_max_range = {range_val}
channels = {channels}
reverse = {reverse}
"""

        with open(self.config_file, "w") as f:
            f.write(config_content)

    def start(self, bars=16, range_val=15, channels="stereo", reverse=0):
        """Start the cava server"""
        self.shutdown_event = threading.Event()
        threads = []
        try:
            self.temp_dir.mkdir(parents=True, exist_ok=True)
            self.server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                self.server_socket.bind(self.socket_file)
                self.server_socket.listen(10)
            except OSError as e:
                error_msg = {
                    98: "Error: Cava manager is already running",
                    2: None,  # Handle directory creation separately
                }.get(e.errno, f"Error: Could not bind to socket: {e}")

                if e.errno == 2:
                    os.makedirs(os.path.dirname(self.socket_file), exist_ok=True)
                    try:
                        self.server_socket.bind(self.socket_file)
                        self.server_socket.listen(10)
                    except OSError as e2:
                        error_msg = (
                            "Error: Cava manager is already running"
                            if e2.errno == 98
                            else f"Error: Could not bind to socket: {e2}"
                        )
                        print(error_msg)
                        self.server_socket.close()
                        self.server_socket = None
                        sys.exit(1)
                else:
                    print(error_msg)
                    self.server_socket.close()
                    self.server_socket = None
                    sys.exit(1)

            print(f"Cava manager started. Socket: {self.socket_file}")

            if not self.cleanup_registered:
                atexit.register(self.cleanup)
                self.cleanup_registered = True
                self.successfully_started = True

            self._write_pid_file()
            self._create_cava_config(bars, range_val, channels, reverse)

            print(f"Starting cava with config: {self.config_file}")
            try:
                self.cava_process = subprocess.Popen(
                    ["cava", "-p", str(self.config_file)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                print("Error: cava not found. Please install cava.")
                sys.exit(1)

            def read_cava_output():
                import select

                while not self.shutdown_event.is_set():
                    if self.cava_process.stdout:
                        rlist, _, _ = select.select(
                            [self.cava_process.stdout], [], [], 0.2
                        )
                        if rlist:
                            line = self.cava_process.stdout.readline()
                            if not line or self.shutdown_event.is_set():
                                break
                            line_stripped = line.strip()
                            if line_stripped:
                                values = [
                                    x for x in line_stripped.split(";") if x.isdigit()
                                ]
                                if values and all(int(v) == 0 for v in values):
                                    self.consecutive_zero_count += 1
                                    if (
                                        self.consecutive_zero_count
                                        <= self.zero_threshold
                                    ):
                                        self._broadcast_data(line.encode("utf-8"))
                                else:
                                    self.consecutive_zero_count = 0
                                    if values:
                                        self._broadcast_data(line.encode("utf-8"))
                        else:
                            continue
                    else:
                        break

            def handle_client_connections():
                while not self.shutdown_event.is_set():
                    try:
                        self.server_socket.settimeout(0.2)
                        conn, addr = self.server_socket.accept()
                        print("New client connected")
                        threading.Thread(
                            target=self._client_command_listener,
                            args=(conn,),
                            daemon=True,
                        ).start()
                        with self.clients_lock:
                            self.clients.append(conn)
                            self.last_client_time = time.time()
                    except socket.timeout:
                        continue
                    except OSError:
                        break

            def check_auto_shutdown():
                # Auto-shutdown disabled: manager stays alive between waybar restarts
                # so media.js and other clients can reconnect without a re-launch.
                pass

            threads.append(
                threading.Thread(target=handle_client_connections, daemon=True)
            )
            threads.append(threading.Thread(target=check_auto_shutdown, daemon=True))
            threads.append(threading.Thread(target=read_cava_output, daemon=True))
            for t in threads:
                t.start()

            def shutdown_handler(signum=None, frame=None):
                self.shutdown_event.set()
                for t in threads:
                    t.join(timeout=2)
                if self.cava_process and self.cava_process.poll() is None:
                    try:
                        self.cava_process.terminate()
                        self.cava_process.wait(timeout=2)
                    except Exception:
                        try:
                            self.cava_process.kill()
                        except Exception:
                            pass
                self.cleanup()
                os._exit(0)

            signal.signal(signal.SIGTERM, shutdown_handler)
            signal.signal(signal.SIGINT, shutdown_handler)
            try:
                while not self.shutdown_event.is_set():
                    time.sleep(0.2)
            except KeyboardInterrupt:
                shutdown_handler()

        except Exception as e:
            print(f"Error starting manager: {e}")
            sys.exit(1)
        finally:
            self.cleanup()
            os._exit(0)

    def is_running(self):
        """Check if the server is running"""
        return self._quick_check_running()

    def start_in_background(self, bars=64, range_val=15):
        """Start the manager in background and return immediately"""
        if self.is_running():
            return True

        script_path = os.path.abspath(__file__)
        try:
            process = subprocess.Popen(
                [
                    sys.executable,
                    script_path,
                    "manager",
                    "--bars",
                    str(bars),
                    "--range",
                    str(range_val),
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )

            max_wait = 5
            start_time = time.time()
            while time.time() - start_time < max_wait:
                if self.is_running():
                    return True
                time.sleep(0.1)

            if process.poll() is None:
                time.sleep(0.5)
                if self.is_running():
                    return True

            return False
        except Exception as e:
            print(f"Failed to start manager in background: {e}", file=sys.stderr)
            return False



class QMLColorUpdater:
    """Write cava active/inactive state to a small JSON file that Cava.qml watches.
    Replaces CSSColorUpdater when running in quickshell mode — no CSS mutations needed."""

    def __init__(self, state_file=None):
        if state_file is None:
            runtime = os.getenv("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
            state_file = os.path.join(runtime, "quickshell", "cava-state.json")
        self.state_file = state_file
        os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
        self.current_state = None

    def update_for_media_state(self, is_playing):
        if self.current_state == is_playing:
            return False
        self.current_state = is_playing
        try:
            data = json.dumps({"active": is_playing})
            tmp = self.state_file + ".tmp"
            with open(tmp, "w") as f:
                f.write(data)
            os.replace(tmp, self.state_file)
        except Exception as e:
            print(f"QMLColorUpdater write error: {e}", file=sys.stderr)
        return True

    def cleanup(self):
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, "w") as f:
                    f.write(json.dumps({"active": True}))
        except Exception:
            pass

class CavaClient:
    """Cava client that connects to the server and formats output"""

    def __init__(self):
        self.runtime_dir = os.getenv(
            "XDG_RUNTIME_DIR", os.path.join("/run/user", str(os.getuid()))
        )
        self.socket_file = os.path.join(self.runtime_dir, "hyprcandy", "cava.sock")
        self.parser = CavaDataParser()
        self.media_detector = MediaDetector()
        self.css_updater = None  # Will be initialized if transparent_when_inactive is True

    def _auto_start_manager_if_needed(self, bars=64, range_val=15):
        """Automatically start manager if not running"""
        server = CavaServer()
        if not server.is_running():
            print("Manager not running, starting automatically...", file=sys.stderr)
            if server.start_in_background(bars, range_val):
                print("Manager started successfully", file=sys.stderr)
                return True
            else:
                print("Failed to start manager automatically", file=sys.stderr)
                return False
        return True

    def start(
        self,
        bar_chars="▁▂▃▄▅▆▇█",
        width=None,
        standby_mode=0,
        timeout=10,
        bars=64,
        range_val=15,
        json_output=False,
        hide_when_inactive=False,
        transparent_when_inactive=False,
        reverse=False,
        qs_mode=False,
    ):
        """Start the cava client with enhanced hiding functionality"""
        if not self._auto_start_manager_if_needed(bars, range_val):
            print("Error: Could not start cava manager", file=sys.stderr)
            sys.exit(1)

        # Initialize color updater based on mode
        if transparent_when_inactive:
            if qs_mode:
                self.css_updater = QMLColorUpdater()
                print("QML state updater initialized", file=sys.stderr)
            else:
                self.css_updater = CSSColorUpdater()
                print("CSS color updater initialized", file=sys.stderr)

        start_time = time.time()
        while not os.path.exists(self.socket_file):
            if time.time() - start_time > timeout:
                print(
                    "Error: Cava manager not accessible after timeout", file=sys.stderr
                )
                sys.exit(1)
            time.sleep(0.1)

        try:
            client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            client_socket.connect(self.socket_file)

            # Track state for hiding functionality
            last_media_check = 0
            media_check_interval = 0.5 if transparent_when_inactive else 2  # Check more frequently with CSS updates
            consecutive_silent_count = 0
            silent_threshold = 10  # Hide after 10 consecutive silent readings
            is_hidden = False
            last_output_time = time.time()

            # Initial media check and standby output
            is_media_playing = self.media_detector.is_media_playing(force_check=True)
            
            # Update CSS colors based on initial media state
            if transparent_when_inactive and self.css_updater:
                self.css_updater.update_for_media_state(is_media_playing)
            
            if not is_media_playing and hide_when_inactive:
                # If no media is playing and hide_when_inactive is True, output empty and hide
                if json_output:
                    output = {"text": "", "class": "cava-hidden"}
                    print(json.dumps(output), flush=True)
                else:
                    print("", flush=True)
                is_hidden = True
            else:
                # Show initial standby output
                standby_output = self.parser._handle_standby_mode(
                    standby_mode, bar_chars, width
                )
                if not (
                    (standby_mode == 0 and standby_output == "")
                    or (standby_mode == "" and standby_output == "")
                ):
                    if json_output:
                        output = {
                            "text": standby_output,
                            "tooltip": "Cava audio visualizer - standby mode",
                            "class": "cava-standby"
                        }
                        print(json.dumps(output), flush=True)
                    else:
                        print(standby_output, flush=True)

            buffer = ""
            while True:
                current_time = time.time()
                
                # Periodically check media status
                if (hide_when_inactive or transparent_when_inactive) and current_time - last_media_check > media_check_interval:
                    is_media_playing = self.media_detector.is_media_playing()
                    last_media_check = current_time
                    
                    # Update CSS colors if transparent_when_inactive is enabled
                    if transparent_when_inactive and self.css_updater:
                        self.css_updater.update_for_media_state(is_media_playing)
                    
                    # If media stopped and we're not hidden yet, hide immediately
                    if hide_when_inactive and not is_media_playing and not is_hidden:
                        if json_output:
                            output = {"text": "", "class": "cava-hidden"}
                            print(json.dumps(output), flush=True)
                        else:
                            print("", flush=True)
                        is_hidden = True
                        consecutive_silent_count = 0
                        continue
                    
                    # If media started and we're hidden, show standby mode
                    elif is_media_playing and is_hidden:
                        is_hidden = False
                        consecutive_silent_count = 0

                data = client_socket.recv(1024)
                if not data:
                    break

                decoded_data = data.decode("utf-8")
                if decoded_data.strip():
                    buffer += decoded_data

                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        if line.strip():
                            # Parse the data to check for silence
                            try:
                                values = [int(x) for x in line.split(";") if x.isdigit()]
                                is_silent = not values or all(v == 0 for v in values)
                            except ValueError:
                                is_silent = True
                            
                            # Handle hiding logic or CSS updates
                            if hide_when_inactive or transparent_when_inactive:
                                # Check if media is still playing
                                if current_time - last_media_check > media_check_interval:
                                    is_media_playing = self.media_detector.is_media_playing()
                                    last_media_check = current_time
                                    
                                    # Update CSS colors if transparent_when_inactive is enabled
                                    if transparent_when_inactive and self.css_updater:
                                        self.css_updater.update_for_media_state(is_media_playing)
                                
                                if hide_when_inactive and not is_media_playing:
                                    # No media playing - hide immediately
                                    if not is_hidden:
                                        if json_output:
                                            output = {"text": "", "class": "cava-hidden"}
                                            print(json.dumps(output), flush=True)
                                        else:
                                            print("", flush=True)
                                        is_hidden = True
                                    continue
                                
                                elif hide_when_inactive and is_silent:
                                    # Media is playing but audio is silent
                                    consecutive_silent_count += 1
                                    if consecutive_silent_count >= silent_threshold and not is_hidden:
                                        # Hide after extended silence even if media is "playing"
                                        if json_output:
                                            output = {"text": "", "class": "cava-hidden"}
                                            print(json.dumps(output), flush=True)
                                        else:
                                            print("", flush=True)
                                        is_hidden = True
                                    elif not is_hidden:
                                        # Show standby mode during brief silence
                                        standby_output = self.parser._handle_standby_mode(
                                            standby_mode, bar_chars, width
                                        )
                                        if json_output:
                                            output = {
                                                "text": standby_output,
                                                "tooltip": "Cava audio visualizer - silent",
                                                "class": "cava-silent"
                                            }
                                            print(json.dumps(output), flush=True)
                                        else:
                                            if standby_output:
                                                print(standby_output, flush=True)
                                    continue
                                
                                elif hide_when_inactive:
                                    # Audio activity detected - show and reset counters
                                    consecutive_silent_count = 0
                                    is_hidden = False

                            # Format and display the audio data
                            formatted = self.parser.format_data(
                                line, bar_chars, width, standby_mode, "", reverse
                            )
                            
                            should_suppress = (
                                standby_mode == 0 and formatted == ""
                            ) or (standby_mode == "" and formatted == "")
                            
                            if not should_suppress and not (hide_when_inactive and is_hidden):
                                last_output_time = current_time
                                if json_output:
                                    css_class = "cava-active" if not is_silent else "cava-silent"
                                    output = {
                                        "text": formatted,
                                        "tooltip": "Cava audio visualizer - active",
                                        "class": css_class
                                    }
                                    print(json.dumps(output), flush=True)
                                else:
                                    print(formatted, flush=True)

        except (ConnectionRefusedError, FileNotFoundError):
            print("Error: Cannot connect to cava manager", file=sys.stderr)
            sys.exit(1)
        except KeyboardInterrupt:
            pass
        finally:
            # Cleanup CSS colors before exit
            if transparent_when_inactive and self.css_updater:
                self.css_updater.cleanup()
            
            try:
                client_socket.close()
            except Exception:
                pass

    @staticmethod
    def parse_command_config(cava_config, command, args):
        """Parse configuration for a specific command type"""
        prefix = f"CAVA_{command.upper()}"

        # Prefer --bar-array if present
        if hasattr(args, "bar_array") and args.bar_array:
            bar_chars = args.bar_array
        else:
            # Prefer BAR_ARRAY from config if present and is a list
            bar_array = cava_config.get_value(f"{prefix}_BAR_ARRAY")
            if bar_array and isinstance(bar_array, list):
                bar_chars = bar_array
            else:
                bar_chars = args.bar or cava_config.get_value(
                    f"{prefix}_BAR", "▁▂▃▄▅▆▇█"
                )
                if isinstance(bar_chars, str):
                    bar_chars = list(bar_chars)

        width = (
            args.width
            if args.width is not None
            else int(cava_config.get_value(f"{prefix}_WIDTH", "0") or 0)
        )
        if not width:
            width = len(bar_chars) if bar_chars else 8

        if args.stb is not None:
            standby_mode = args.stb
            if isinstance(standby_mode, str) and standby_mode.isdigit():
                standby_mode = int(standby_mode)
        else:
            standby_mode = cava_config.get_value(f"{prefix}_STANDBY", "0")
            if standby_mode is None or standby_mode == "":
                standby_mode = "\n"
            elif isinstance(standby_mode, str) and standby_mode.isdigit():
                standby_mode = int(standby_mode)
        
        # Handle reverse flag for --left/--right
        reverse = False
        if hasattr(args, 'direction') and args.direction:
            if args.direction == 'right':
                reverse = True
            elif args.direction == 'left':
                reverse = False

        return bar_chars, width, standby_mode, reverse


class CavaReloadClient:
    """Minimal client to send reload command to the server"""

    def __init__(self):
        self.runtime_dir = os.getenv(
            "XDG_RUNTIME_DIR", os.path.join("/run/user", str(os.getuid()))
        )
        self.socket_file = os.path.join(self.runtime_dir, "hyprcandy", "cava.sock")

    def reload(self):
        if not os.path.exists(self.socket_file):
            print("Cava manager is not running.")
            sys.exit(1)
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.connect(self.socket_file)
            s.sendall(b"CMD:RELOAD\n")
            s.close()
            print("Reload command sent.")
        except Exception as e:
            print(f"Failed to send reload command: {e}")
            sys.exit(1)


def create_client_parser(subparsers, name, help_text):
    """Create a client parser with common arguments"""
    parser = subparsers.add_parser(name, help=help_text)
    parser.add_argument("--bar", default=None, help="Bar characters")
    parser.add_argument(
        "--bar-array",
        nargs="+",
        help="Bar characters as an array (e.g. --bar-array '<span color=red>#</span>' '<span color=green>#</span>')",
    )
    parser.add_argument("--width", type=int, help="Bar width")
    parser.add_argument(
        "--stb",
        default=None,
        help='Standby mode (0-3 or string): 0=clean (totally hides the module), 1=blank (makes module expand as spaces), 2=full (occupies the module with full bar), 3=low (makes the module display the lowest set bar), ""=displays nothing and compresses the module, string=displays the custom string',
    )
    parser.add_argument(
        "--hide-when-inactive",
        action="store_true",
        help="Hide the visualizer when no media is playing or after extended silence"
    )
    parser.add_argument(
        "--transparent-when-inactive",
        action="store_true",
        help="Make bars transparent when silent instead of hiding (keeps module space)"
    )
    parser.add_argument(
        "--left",
        action="store_const",
        const="left",
        dest="direction",
        help="Display bars in normal order (left to right, low to high frequencies)"
    )
    parser.add_argument(
        "--right",
        action="store_const",
        const="right",
        dest="direction",
        help="Display bars in reversed order (right to left, high to low frequencies) - perfect for right-side modules"
    )
    if name in ("waybar", "quickshell"):
        parser.add_argument(
            "--json", action="store_true", help="Output JSON format"
        )
    return parser


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Cava Manager and Client")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    manager_parser = subparsers.add_parser("manager", help="Start cava manager")
    manager_parser.add_argument("--bars", type=int, default=64, help="Number of bars")
    manager_parser.add_argument("--range", type=int, default=15, help="ASCII range")
    manager_parser.add_argument(
        "--channels",
        choices=["mono", "stereo"],
        default="stereo",
        help="Audio channels: mono or stereo",
    )
    manager_parser.add_argument(
        "--reverse",
        type=int,
        choices=[0, 1],
        default=0,
        help="Reverse frequency order: 0=normal, 1=reverse",
    )

    create_client_parser(subparsers, "waybar", "Waybar client")
    create_client_parser(subparsers, "quickshell", "Quickshell/QML client (writes JSON state instead of CSS)")
    create_client_parser(subparsers, "stdout", "Stdout client")
    create_client_parser(subparsers, "hyprlock", "Hyprlock client")

    subparsers.add_parser("status", help="Check manager status")
    subparsers.add_parser("reload", help="Reload cava manager (restart cava process)")

    args = parser.parse_args()

    if args.command == "manager":
        server = CavaServer()
        if server.is_running():
            print("Cava manager is already running")
            sys.exit(0)

        server.start(args.bars, args.range, args.channels, args.reverse)

    elif args.command in ["waybar", "quickshell", "stdout", "hyprlock"]:
        cava_config = CavaConfig()

        bar_chars, width, standby_mode, reverse = CavaClient.parse_command_config(
            cava_config, args.command, args
        )

        bars = int(cava_config.get_value("CAVA_BARS", 64))
        range_val = int(cava_config.get_value("CAVA_RANGE", "15"))

        json_output = args.command in ("waybar", "quickshell") and hasattr(args, "json") and args.json
        hide_when_inactive = hasattr(args, "hide_when_inactive") and args.hide_when_inactive
        transparent_when_inactive = hasattr(args, "transparent_when_inactive") and args.transparent_when_inactive
        qs_mode = args.command == "quickshell"

        client = CavaClient()
        client.start(
            bar_chars,
            width,
            standby_mode,
            bars=bars,
            range_val=range_val,
            json_output=json_output,
            hide_when_inactive=hide_when_inactive,
            transparent_when_inactive=transparent_when_inactive,
            reverse=reverse,
            qs_mode=qs_mode,
        )

    elif args.command == "status":
        server = CavaServer()
        if server.is_running():
            print("Cava manager is running")
            sys.exit(0)
        else:
            print("Cava manager is not running")
            sys.exit(1)

    elif args.command == "reload":
        CavaReloadClient().reload()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
