#!/bin/bash
# Set blur passes value directly
HYPR_CONF="$HOME/.config/hypr/hyprviz.conf"

value="$1"

if [ -n "$value" ] && [ -f "$HYPR_CONF" ]; then
    # Validate and clamp between 0 and 10
    nv=$(echo "$value" | grep -oP '[0-9]+')
    if [ -n "$nv" ]; then
        [ "$nv" -lt 0 ] 2>/dev/null && nv=0
        [ "$nv" -gt 10 ] 2>/dev/null && nv=10
        sed -i '/blur {/,/^}/ s/passes = [0-9]*/passes = '"$nv"'/' "$HYPR_CONF"
        hyprctl reload
        echo "ok"
    fi
fi
