#!/bin/bash
# Set border radius (rounding) value directly
HYPR_CONF="$HOME/.config/hypr/hyprviz.conf"

value="$1"

if [ -n "$value" ] && [ -f "$HYPR_CONF" ]; then
    # Validate and clamp between 0 and 50
    nv=$(echo "$value" | grep -oP '[0-9]+')
    if [ -n "$nv" ]; then
        [ "$nv" -lt 0 ] 2>/dev/null && nv=0
        [ "$nv" -gt 50 ] 2>/dev/null && nv=50
        sed -i '/decoration {/,/^}/ s/rounding = [0-9]*/rounding = '"$nv"'/' "$HYPR_CONF"
        hyprctl reload
        echo "ok"
    fi
fi
