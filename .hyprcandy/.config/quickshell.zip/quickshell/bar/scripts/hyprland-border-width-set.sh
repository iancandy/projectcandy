#!/bin/bash
# Set border width (border_size) value directly
HYPR_CONF="$HOME/.config/hypr/hyprviz.conf"

value="$1"

if [ -n "$value" ] && [ -f "$HYPR_CONF" ]; then
    # Validate and clamp between 0 and 20
    nv=$(echo "$value" | grep -oP '[0-9]+')
    if [ -n "$nv" ]; then
        [ "$nv" -lt 0 ] 2>/dev/null && nv=0
        [ "$nv" -gt 20 ] 2>/dev/null && nv=20
        sed -i '/decoration {/,/^}/ s/border_size = [0-9]*/border_size = '"$nv"'/' "$HYPR_CONF"
        hyprctl reload
        echo "ok"
    fi
fi
