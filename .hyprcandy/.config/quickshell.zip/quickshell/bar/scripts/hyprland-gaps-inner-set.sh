#!/bin/bash
# Set inner gaps value directly
HYPR_CONF="$HOME/.config/hypr/hyprviz.conf"

value="$1"

if [ -n "$value" ] && [ -f "$HYPR_CONF" ]; then
    # Validate and clamp between 0 and 100
    nv=$(echo "$value" | grep -oP '[0-9]+')
    if [ -n "$nv" ]; then
        [ "$nv" -lt 0 ] 2>/dev/null && nv=0
        [ "$nv" -gt 100 ] 2>/dev/null && nv=100
        sed -i '/general {/,/^}/ s/gaps_in = [0-9]*/gaps_in = '"$nv"'/' "$HYPR_CONF"
        hyprctl reload
        echo "ok"
    fi
fi
